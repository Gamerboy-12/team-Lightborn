// Run this script to seed the database with sample data
// Usage: npx ts-node scripts/seed.ts

import { createClient } from '../lib/supabase/server'

const sampleCourses = [
  {
    title: 'Web Development Fundamentals',
    description: 'Learn the basics of HTML, CSS, and JavaScript to build beautiful websites.',
    category: 'Development',
    level: 'Beginner',
    duration_hours: 20,
    price: 0,
  },
  {
    title: 'Advanced React Patterns',
    description: 'Master advanced React techniques including hooks, context, and performance optimization.',
    category: 'Development',
    level: 'Advanced',
    duration_hours: 30,
    price: 49.99,
  },
  {
    title: 'Data Science with Python',
    description: 'Learn data analysis, visualization, and machine learning with Python.',
    category: 'Data Science',
    level: 'Intermediate',
    duration_hours: 40,
    price: 79.99,
  },
  {
    title: 'UI/UX Design Fundamentals',
    description: 'Create beautiful and functional user interfaces that users love.',
    category: 'Design',
    level: 'Beginner',
    duration_hours: 25,
    price: 39.99,
  },
  {
    title: 'Business Strategy Essentials',
    description: 'Learn the fundamentals of strategic planning and business development.',
    category: 'Business',
    level: 'Intermediate',
    duration_hours: 15,
    price: 59.99,
  },
  {
    title: 'Cloud Computing with AWS',
    description: 'Master Amazon Web Services and cloud architecture design.',
    category: 'Technology',
    level: 'Advanced',
    duration_hours: 35,
    price: 99.99,
  },
  {
    title: 'Creative Writing Masterclass',
    description: 'Develop your writing skills and bring your stories to life.',
    category: 'Creative',
    level: 'Beginner',
    duration_hours: 20,
    price: 29.99,
  },
  {
    title: 'Mobile App Development',
    description: 'Build production-ready mobile applications for iOS and Android.',
    category: 'Development',
    level: 'Intermediate',
    duration_hours: 45,
    price: 89.99,
  },
]

const sampleInstructors = [
  {
    title: 'Senior Full Stack Developer',
    bio: '10+ years of experience building web applications at scale.',
    verified: true,
  },
  {
    title: 'Data Science Expert',
    bio: 'PhD in Machine Learning with experience at top tech companies.',
    verified: true,
  },
  {
    title: 'UI/UX Designer',
    bio: 'Award-winning designer with a passion for user-centered design.',
    verified: true,
  },
  {
    title: 'Business Consultant',
    bio: 'Helped 100+ startups scale to success.',
    verified: true,
  },
  {
    title: 'AWS Solutions Architect',
    bio: 'Certified AWS Solutions Architect with 8+ years of cloud experience.',
    verified: true,
  },
  {
    title: 'Creative Writing Coach',
    bio: 'Published author with multiple bestselling books.',
    verified: true,
  },
  {
    title: 'Mobile Developer',
    bio: 'Created 50+ mobile apps with millions of downloads.',
    verified: true,
  },
]

async function seed() {
  try {
    const supabase = await createClient()

    console.log('Creating instructors...')
    const instructorIds: string[] = []

    for (const instructor of sampleInstructors) {
      const email = `instructor${instructorIds.length + 1}@edustream.com`
      const password = 'TempPassword123!'

      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      })

      if (authError) {
        console.error(`Error creating instructor auth: ${authError.message}`)
        continue
      }

      // Create instructor profile
      const { error: profileError } = await supabase.from('profiles').insert({
        id: authData.user.id,
        email,
        full_name: `${instructor.title.split(' ')[0]} Instructor`,
      })

      if (profileError) {
        console.error(`Error creating instructor profile: ${profileError.message}`)
        continue
      }

      // Create instructor record
      const { error: instructorError } = await supabase.from('instructors').insert({
        id: authData.user.id,
        ...instructor,
      })

      if (instructorError) {
        console.error(`Error creating instructor: ${instructorError.message}`)
        continue
      }

      instructorIds.push(authData.user.id)
      console.log(`✓ Created instructor: ${instructor.title}`)
    }

    console.log('\nCreating courses...')
    for (let i = 0; i < sampleCourses.length; i++) {
      const course = sampleCourses[i]
      const instructorId = instructorIds[i % instructorIds.length]

      const { data: courseData, error: courseError } = await supabase
        .from('courses')
        .insert({
          instructor_id: instructorId,
          ...course,
          is_published: true,
          total_reviews: Math.floor(Math.random() * 100) + 10,
          total_students: Math.floor(Math.random() * 1000) + 100,
          rating: (Math.random() * 1 + 4).toFixed(1),
        })
        .select()
        .single()

      if (courseError) {
        console.error(`Error creating course: ${courseError.message}`)
        continue
      }

      console.log(`✓ Created course: ${course.title}`)

      // Create lessons for the course
      const lessonCount = Math.floor(Math.random() * 5) + 3
      for (let j = 0; j < lessonCount; j++) {
        const { error: lessonError } = await supabase.from('lessons').insert({
          course_id: courseData.id,
          title: `Lesson ${j + 1}: ${course.title}`,
          lesson_number: j + 1,
          video_duration_seconds: Math.floor(Math.random() * 2400) + 300,
          description: `Learn about module ${j + 1} of ${course.title}`,
        })

        if (lessonError) {
          console.error(`Error creating lesson: ${lessonError.message}`)
        }
      }
    }

    console.log('\n✅ Database seeded successfully!')
  } catch (error) {
    console.error('Seeding error:', error)
    process.exit(1)
  }
}

seed()
