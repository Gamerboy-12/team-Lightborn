# EduStream - The Netflix of Education

A modern, full-featured online learning platform built with Next.js 16, Supabase, and shadcn/ui. Stream unlimited learning, find your passion, and master new skills with thousands of expert-led courses.

## 🚀 Features

### Core Features (Phase 1-2 - Complete)
- ✅ **Modern Landing Page** - Stunning hero section with compelling value proposition
- ✅ **Course Catalog** - Browse and filter courses by category and level
- ✅ **User Authentication** - Secure email/password authentication with Supabase
- ✅ **Course Detail Pages** - Comprehensive course information with reviews and lessons
- ✅ **Database Schema** - Complete relational database with 10 tables
- ✅ **Row Level Security** - Enterprise-grade data protection with RLS policies

### Features in Progress
- 🔄 **Video Player** - Embedded video lessons with progress tracking
- 🔄 **Student Dashboard** - Learning progress analytics and enrolled courses
- 🔄 **Progress Tracking** - Track lesson completion and course progress
- 🔄 **Certificates** - Shareable certificates upon course completion

### Upcoming Features
- 🎯 **AI-Powered Recommendations** - Personalized course suggestions
- 🎯 **Social Features** - Course discussions, Q&A, and peer learning
- 🎯 **Instructor Dashboard** - Tools for creating and managing courses
- 🎯 **Advanced Analytics** - Learning insights and performance metrics

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 16 (App Router), React 19, Tailwind CSS 4
- **Authentication**: Supabase Auth
- **Database**: Supabase PostgreSQL
- **UI Components**: shadcn/ui with Radix UI
- **Data Fetching**: SWR for client-side state management
- **Validation**: React Hook Form + Zod
- **Icons**: Lucide React

### Database Schema

```
┌─────────────┐
│   auth.users│ (Supabase Auth)
└──────┬──────┘
       │
       ├─→ profiles (user data)
       ├─→ instructors (instructor data)
       ├─→ enrollments (course enrollments)
       ├─→ lesson_progress (lesson tracking)
       ├─→ certificates (earned certificates)
       ├─→ reviews (course reviews)
       ├─→ discussions (Q&A discussions)
       └─→ discussion_replies (replies)
       
   ┌─────────────┐
   │   courses   │
   ├─────────────┤
   └──→ lessons  (course content)
```

### File Structure
```
app/
├── layout.tsx              # Root layout with dark mode
├── page.tsx                # Landing page
├── globals.css             # Tailwind config with dark theme
├── auth/
│   ├── login/page.tsx
│   ├── sign-up/page.tsx
│   ├── callback/route.ts   # Auth callback handler
│   └── error/page.tsx
├── catalog/
│   └── page.tsx            # Course browsing & filtering
├── course/
│   └── [id]/page.tsx       # Course detail & enrollment
└── api/
    └── demo-setup/route.ts # Sample data initialization

lib/
├── supabase/
│   ├── client.ts           # Browser client
│   ├── server.ts           # Server client
│   └── proxy.ts            # Session management
├── db.ts                   # Database utility functions
└── utils.ts

components/
├── header.tsx              # Persistent header with auth
└── ui/*                    # shadcn/ui components

hooks/
└── use-courses.ts          # SWR hooks for data fetching

scripts/
└── seed.ts                 # Database seeding script
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- pnpm (or npm/yarn)
- Supabase account with a project

### Installation

1. **Clone and install**
```bash
pnpm install
```

2. **Set up environment variables** in `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

3. **Start the development server**
```bash
pnpm dev
```

Visit `http://localhost:3000` to see the landing page.

### Initialize Demo Data

After setting up authentication, you can populate the database with sample courses and instructors:

```bash
# Using the API endpoint (requires authentication)
curl -X POST http://localhost:3000/api/demo-setup \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Or use the seed script (requires admin access):
```bash
pnpm ts-node scripts/seed.ts
```

## 📖 Usage

### User Flows

**1. Landing Page**
- Browse the platform overview
- View key statistics
- Sign up or log in

**2. Course Discovery**
- Visit `/catalog` to browse courses
- Filter by category and difficulty level
- Search by keyword
- View course details and reviews

**3. Enrollment**
- Click "Enroll Now" on any course
- Automatically redirected to `/course/[id]/learn`
- Access course content and lessons

**4. Learning**
- Watch video lessons
- Track progress automatically
- Complete lessons to progress through the course
- Access discussions and Q&A

### Authentication

The platform uses Supabase Auth with email/password authentication:

- **Sign Up**: `/auth/sign-up`
- **Login**: `/auth/login`
- **Logout**: Available in the header dropdown

Email confirmation is required by default. Users are redirected to `/auth/sign-up-success` after signup.

## 🗄️ Database Operations

All database operations are handled through utility functions in `lib/db.ts`:

```typescript
// Get all published courses
const courses = await getCourses()

// Get course with instructor info and reviews
const course = await getCourseById(courseId)

// Enroll user in a course
const enrollment = await enrollInCourse(userId, courseId)

// Get user's enrollments
const enrollments = await getUserEnrollments(userId)

// Create a course review
const review = await createReview(userId, courseId, {
  rating: 5,
  title: 'Great course!',
  comment: 'Learned so much!'
})
```

## 🎨 Design System

### Color Palette
- **Primary**: Vibrant Blue (#605 256 264.376) - main actions
- **Accent**: Orange (#729 242 31.736) - highlights
- **Background**: Very dark gray (#12 0 0) - main background
- **Card**: Dark gray (#18 0 0) - card surfaces
- **Text**: White/Off-white (#98 0 0) - foreground text

### Typography
- **Font**: Geist (Google Font)
- **Headings**: Bold weights (600-700)
- **Body**: Regular weight (400)
- **Mono**: Geist Mono for code

### Components
All components use shadcn/ui with custom styling:
- Buttons with hover states
- Cards for content containers
- Dropdowns for menus
- Form inputs with validation
- Badges for tags and status

## 🔐 Security

### Row Level Security (RLS)
All database tables have RLS policies enforced:
- Users can only view/edit their own enrollments and progress
- Instructors can only manage their own courses
- Public course browsing for published courses
- Discussion access limited to enrolled users

### Best Practices
- All data writes checked against `auth.uid()`
- Password hashing handled by Supabase
- Session management with HTTP-only cookies
- CORS protection on API routes

## 📊 Phase Breakdown

### Phase 1: Setup Database & Auth ✅
- Database schema with 10 tables
- RLS policies for security
- Supabase Auth integration
- Middleware for session management

### Phase 2: Landing & Catalog 🔄 In Progress
- Landing page with hero section
- Course catalog with filtering
- Course detail pages
- Enrollment functionality

### Phase 3: Video Player & Learning
- Video player component
- Lesson progress tracking
- Course completion tracking

### Phase 4: Dashboard & Analytics
- Student dashboard
- Progress analytics
- Certificate generation and sharing

### Phase 5: Social & AI Features
- Course discussions
- AI-powered recommendations
- Instructor management tools
- Advanced analytics

## 🐛 Debugging

### Common Issues

**"Middleware deprecation warning"**
- This is expected in Next.js 16. The platform uses `middleware.ts` which will be converted to `proxy.js` in a future update.

**Authentication not working**
- Verify `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` are correct
- Check that email confirmation is not required (or confirm the email manually)
- Check the Supabase dashboard for auth errors

**Database operations failing**
- Verify RLS policies are in place (check Supabase dashboard)
- Ensure the user is authenticated before making queries
- Check browser console for detailed error messages

**Courses not showing**
- Run the demo setup to create sample data
- Verify courses have `is_published = true`
- Check RLS policies allow reading published courses

## 📝 Development Notes

### Adding a New Course Category
1. Update `categories` array in `/app/catalog/page.tsx`
2. Courses with that category will automatically appear in filters

### Adding New Lessons
1. Use the database utility: `createLessonProgress()`
2. Lessons are automatically ordered by `lesson_number`

### Customizing the Theme
1. Edit color tokens in `/app/globals.css`
2. Use Tailwind design tokens: `bg-primary`, `text-foreground`, etc.
3. Dark mode is enabled by default on `<html className="dark">`

## 📚 Resources

- [Next.js 16 Docs](https://nextjs.org)
- [Supabase Docs](https://supabase.com/docs)
- [shadcn/ui Components](https://ui.shadcn.com)
- [Tailwind CSS 4](https://tailwindcss.com)

## 📄 License

MIT

## 🤝 Contributing

This is a competition project for "Netflix of Education". All features and improvements should align with the platform vision of democratizing access to high-quality education.

---

**Version**: 0.2.0 (Phase 2 - Landing & Catalog)  
**Last Updated**: 2024
