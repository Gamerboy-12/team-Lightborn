import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

// Demo setup - creates sample instructors and courses
// Warning: This is for demo purposes only. Use with caution.
export async function POST() {
  try {
    const supabase = await createClient()

    // Get the current user to verify they're authorized
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Create sample instructors
    const instructors = [
      {
        title: 'Senior Full Stack Developer',
        bio: '10+ years of experience building web applications at scale.',
        verified: true,
      },
      {
        title: 'Data Science Expert',
        bio: 'PhD in Machine Learning with experience at top tech companies.',
        verified: true,
      },
      {
        title: 'UI/UX Designer',
        bio: 'Award-winning designer with a passion for user-centered design.',
        verified: true,
      },
    ]

    const courses = [
      {
        title: 'Web Development Fundamentals',
        description: 'Learn the basics of HTML, CSS, and JavaScript to build beautiful websites.',
        category: 'Development',
        level: 'Beginner',
        duration_hours: 20,
        price: 0,
      },
      {
        title: 'Advanced React Patterns',
        description: 'Master advanced React techniques including hooks, context, and performance optimization.',
        category: 'Development',
        level: 'Advanced',
        duration_hours: 30,
        price: 49.99,
      },
      {
        title: 'Data Science with Python',
        description: 'Learn data analysis, visualization, and machine learning with Python.',
        category: 'Data Science',
        level: 'Intermediate',
        duration_hours: 40,
        price: 79.99,
      },
    ]

    // Check if demo data already exists
    const { data: existingInstructors } = await supabase
      .from('instructors')
      .select('id')
      .limit(1)

    if (existingInstructors && existingInstructors.length > 0) {
      return NextResponse.json({ message: 'Demo data already exists' }, { status: 200 })
    }

    // Create instructors with auth accounts
    const createdInstructors = []
    for (let i = 0; i < instructors.length; i++) {
      const instructor = instructors[i]
      const email = `demo-instructor-${i + 1}@edustream.demo`

      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email,
        password: 'DemoPassword123!',
        email_confirm: true,
      })

      if (authError) {
        console.error('Auth error:', authError)
        continue
      }

      // Create profile
      await supabase.from('profiles').insert({
        id: authData.user.id,
        email,
        full_name: `${instructor.title.split(' ')[0]} Instructor`,
      })

      // Create instructor record
      await supabase.from('instructors').insert({
        id: authData.user.id,
        ...instructor,
      })

      createdInstructors.push(authData.user.id)
    }

    // Create sample courses
    for (let i = 0; i < courses.length; i++) {
      const course = courses[i]
      const instructorId = createdInstructors[i % createdInstructors.length]

      const { data: courseData } = await supabase
        .from('courses')
        .insert({
          instructor_id: instructorId,
          ...course,
          is_published: true,
          total_reviews: Math.floor(Math.random() * 100) + 10,
          total_students: Math.floor(Math.random() * 1000) + 100,
          rating: (Math.random() * 1 + 4).toFixed(1),
        })
        .select()
        .single()

      if (courseData) {
        // Create sample lessons
        for (let j = 0; j < 5; j++) {
          await supabase.from('lessons').insert({
            course_id: courseData.id,
            title: `Lesson ${j + 1}: ${course.title}`,
            lesson_number: j + 1,
            video_duration_seconds: Math.floor(Math.random() * 2400) + 300,
            description: `Learn about module ${j + 1} of ${course.title}`,
          })
        }
      }
    }

    return NextResponse.json({
      message: 'Demo data created successfully',
      instructors: createdInstructors.length,
      courses: courses.length,
    })
  } catch (error) {
    console.error('Setup error:', error)
    return NextResponse.json(
      { error: 'Failed to setup demo data' },
      { status: 500 }
    )
  }
}
