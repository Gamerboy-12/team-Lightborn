import { generateText } from 'ai'
import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export const maxDuration = 60

export async function POST(req: Request) {
  try {
    const supabase = await createClient()

    // Get current user
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get user's enrolled courses and interests
    const { data: enrollments } = await supabase
      .from('enrollments')
      .select(`
        course:courses(id, title, category, description, level)
      `)
      .eq('user_id', user.id)
      .limit(10)

    // Get all available courses
    const { data: allCourses } = await supabase
      .from('courses')
      .select('id, title, category, description, level, rating, total_students')
      .eq('is_published', true)
      .limit(50)

    if (!allCourses || allCourses.length === 0) {
      return NextResponse.json({
        recommendations: [],
        reasoning: 'No courses available',
      })
    }

    // Build context for AI
    const enrolledCourses = enrollments?.map(e => e.course) || []
    const categories = enrolledCourses.length > 0
      ? Array.from(new Set(enrolledCourses.map(c => c.category)))
      : []
    const levels = enrolledCourses.length > 0
      ? Array.from(new Set(enrolledCourses.map(c => c.level)))
      : []

    const coursesJson = allCourses
      .filter(c => !enrolledCourses.some(e => e.id === c.id))
      .map(c => ({
        id: c.id,
        title: c.title,
        category: c.category,
        level: c.level,
        rating: c.rating || 0,
        popularity: c.total_students || 0,
      }))

    // Use AI to generate personalized recommendations
    const prompt = `You are an expert educational advisor. Based on a student's learning history, recommend the 3-5 most relevant courses for them to take next.

Student's Learning Profile:
- Enrolled Courses: ${enrolledCourses.length > 0 ? enrolledCourses.map(c => c.title).join(', ') : 'None yet'}
- Interested Categories: ${categories.length > 0 ? categories.join(', ') : 'All categories'}
- Current Skill Level: ${levels.length > 0 ? levels.join(', ') : 'Beginner'}

Available Courses:
${JSON.stringify(coursesJson, null, 2)}

Based on the student's profile, recommend courses that:
1. Match their skill level and build on their current knowledge
2. Align with their demonstrated interests
3. Have good ratings and student engagement
4. Provide logical progression in their learning journey

Return a JSON array with up to 5 course recommendations, each with:
{
  "courseId": "UUID",
  "courseTitle": "string",
  "reason": "string explaining why this course is recommended",
  "relevanceScore": 0-100
}

Return ONLY the JSON array, no other text.`

    const result = await generateText({
      model: 'openai/gpt-4o-mini',
      prompt,
      temperature: 0.7,
      maxTokens: 1024,
    })

    // Parse recommendations
    let recommendations = []
    try {
      const jsonMatch = result.text.match(/\[[\s\S]*\]/)
      if (jsonMatch) {
        recommendations = JSON.parse(jsonMatch[0])
        // Validate and enrich recommendations
        recommendations = recommendations
          .filter((rec: any) => rec.courseId && rec.courseTitle)
          .map((rec: any) => ({
            ...rec,
            relevanceScore: Math.min(100, Math.max(0, rec.relevanceScore || 75)),
          }))
          .sort((a: any, b: any) => (b.relevanceScore || 0) - (a.relevanceScore || 0))
          .slice(0, 5)
      }
    } catch (parseError) {
      console.error('Error parsing AI recommendations:', parseError)
    }

    return NextResponse.json({
      recommendations,
      count: recommendations.length,
    })
  } catch (error) {
    console.error('Recommendations error:', error)
    return NextResponse.json(
      { error: 'Failed to generate recommendations' },
      { status: 500 }
    )
  }
}
