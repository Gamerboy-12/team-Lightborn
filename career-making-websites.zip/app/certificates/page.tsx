'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { Award, Download, Share2, Calendar } from 'lucide-react'

export default function CertificatesPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [certificates, setCertificates] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: currentUser },
      } = await supabase.auth.getUser()

      if (!currentUser) {
        router.push('/auth/login')
        return
      }

      setUser(currentUser)

      // Get certificates
      const { data: certificatesData } = await supabase
        .from('certificates')
        .select(`
          *,
          course:courses(id, title, description)
        `)
        .eq('user_id', currentUser.id)
        .order('issued_at', { ascending: false })

      setCertificates(certificatesData || [])
      setLoading(false)
    }

    fetchData()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Loading certificates...</p>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-12">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="mb-12">
            <h1 className="text-4xl font-bold mb-2">My Certificates</h1>
            <p className="text-lg text-muted-foreground">
              Showcase your achievements and share your learning accomplishments
            </p>
          </div>

          {certificates.length === 0 ? (
            <Card className="bg-card/50 border-border/40 p-12 text-center">
              <Award className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-2xl font-bold mb-2">No certificates yet</h3>
              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                Complete courses to earn certificates and showcase your achievements to the world.
              </p>
              <Button className="bg-primary hover:bg-primary/90" asChild>
                <Link href="/catalog">Browse Courses</Link>
              </Button>
            </Card>
          ) : (
            <div className="space-y-6">
              {certificates.map((certificate) => (
                <CertificateCard key={certificate.id} certificate={certificate} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function CertificateCard({ certificate }: { certificate: any }) {
  const [copied, setCopied] = useState(false)

  const handleShare = () => {
    const shareText = `I just completed "${certificate.course?.title}" course on EduStream! Verify my certificate: ${certificate.certificate_number}`
    navigator.clipboard.writeText(shareText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const issueDate = new Date(certificate.issued_at).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  return (
    <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/40 overflow-hidden hover:border-primary/60 transition-all">
      <div className="grid md:grid-cols-2 gap-8 p-8">
        {/* Certificate details */}
        <div className="flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-6">
            <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Award className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Certificate of Completion
              </p>
              <p className="text-sm font-mono text-primary">{certificate.certificate_number}</p>
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-2">{certificate.course?.title}</h2>
          <p className="text-muted-foreground mb-6 line-clamp-2">
            {certificate.course?.description}
          </p>

          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-3">
              <Calendar className="h-4 w-4 text-accent flex-shrink-0" />
              <span className="text-sm">Issued on {issueDate}</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              className="flex-1 bg-primary hover:bg-primary/90"
              onClick={handleShare}
            >
              <Share2 className="h-4 w-4 mr-2" />
              {copied ? 'Copied!' : 'Share Certificate'}
            </Button>
            <Button variant="outline" className="flex-1">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>

        {/* Certificate preview */}
        <div className="flex items-center justify-center">
          <div className="w-full aspect-video bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg border-2 border-dashed border-primary/40 flex items-center justify-center p-8">
            <div className="text-center">
              <Award className="h-16 w-16 text-primary/40 mx-auto mb-4" />
              <p className="text-sm font-semibold text-primary/60 mb-2">Certificate of Completion</p>
              <p className="text-xs text-muted-foreground mb-4 max-w-xs">
                This certificate verifies your successful completion of the course
              </p>
              <p className="text-xs font-mono text-primary/40">
                ID: {certificate.certificate_number}
              </p>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
