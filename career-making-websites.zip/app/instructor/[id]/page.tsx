'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { Star, Users, Award, BarChart3, CheckCircle } from 'lucide-react'

export default function InstructorPage() {
  const params = useParams()
  const instructorId = params.id as string

  const [instructor, setInstructor] = useState<any>(null)
  const [courses, setCourses] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Fetch instructor
      const { data: instructorData, error: instructorError } = await supabase
        .from('instructors')
        .select('*')
        .eq('id', instructorId)
        .single()

      if (instructorError) {
        console.error('Error fetching instructor:', instructorError)
        setLoading(false)
        return
      }

      setInstructor(instructorData)

      // Fetch instructor's courses
      const { data: coursesData } = await supabase
        .from('courses')
        .select('*')
        .eq('instructor_id', instructorId)
        .eq('is_published', true)
        .order('created_at', { ascending: false })

      setCourses(coursesData || [])
      setLoading(false)
    }

    fetchData()
  }, [instructorId])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Loading instructor profile...</p>
        </main>
      </div>
    )
  }

  if (!instructor) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Instructor not found</p>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-12">
        <div className="container mx-auto max-w-6xl px-4">
          {/* Instructor header */}
          <div className="mb-12">
            <div className="grid md:grid-cols-3 gap-8 items-start mb-8">
              {/* Profile info */}
              <div>
                <div className="h-32 w-32 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6">
                  <span className="text-5xl font-bold text-primary-foreground">
                    {instructor.title?.[0]?.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Details */}
              <div className="md:col-span-2">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-4xl font-bold mb-2">{instructor.title}</h1>
                    {instructor.verified && (
                      <p className="text-accent flex items-center gap-2 mb-2">
                        <CheckCircle className="h-4 w-4" />
                        Verified Instructor
                      </p>
                    )}
                  </div>
                </div>

                <p className="text-lg text-muted-foreground mb-8">{instructor.bio}</p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-6">
                  <div>
                    <p className="text-3xl font-bold text-primary mb-1">
                      {instructor.rating?.toFixed(1) || '0.0'}
                    </p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Star className="h-4 w-4 fill-accent text-accent" />
                      Rating
                    </p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-primary mb-1">
                      {instructor.total_students?.toLocaleString() || '0'}
                    </p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      Students
                    </p>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-primary mb-1">
                      {instructor.total_courses || '0'}
                    </p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <BarChart3 className="h-4 w-4" />
                      Courses
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Courses section */}
          <div>
            <h2 className="text-3xl font-bold mb-8">Courses by {instructor.title}</h2>

            {courses.length === 0 ? (
              <Card className="bg-card/50 border-border/40 p-12 text-center">
                <p className="text-muted-foreground">No courses available yet</p>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {courses.map((course) => (
                  <InstructorCourseCard key={course.id} course={course} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

function InstructorCourseCard({ course }: { course: any }) {
  return (
    <Link href={`/course/${course.id}`}>
      <Card className="bg-card/50 border-border/40 hover:bg-card/80 hover:border-primary/30 transition-all overflow-hidden h-full flex flex-col cursor-pointer">
        <div className="h-40 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
          <div className="text-4xl">📚</div>
        </div>

        <div className="p-4 flex flex-col flex-grow">
          <h3 className="font-semibold text-base mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {course.title}
          </h3>

          <p className="text-sm text-muted-foreground mb-4 flex-grow line-clamp-2">
            {course.description}
          </p>

          <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-accent text-accent" />
              <span>{course.rating?.toFixed(1) || '0.0'}</span>
              <span>({course.total_reviews || 0})</span>
            </div>
            <span>{course.duration_hours || '0'}h</span>
          </div>

          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
              course.level === 'Beginner'
                ? 'bg-green-500/20 text-green-400'
                : course.level === 'Intermediate'
                ? 'bg-yellow-500/20 text-yellow-400'
                : 'bg-red-500/20 text-red-400'
            }`}>
              {course.level}
            </span>
            {course.price > 0 && (
              <span className="text-sm font-semibold ml-auto">${course.price?.toFixed(2)}</span>
            )}
            {course.price === 0 && (
              <span className="text-sm font-semibold ml-auto text-accent">Free</span>
            )}
          </div>
        </div>
      </Card>
    </Link>
  )
}
