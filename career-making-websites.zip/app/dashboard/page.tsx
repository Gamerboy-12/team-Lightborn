'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Recommendations } from '@/components/recommendations'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Clock, BookOpen, Award, TrendingUp, Plus, Play } from 'lucide-react'

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [enrollments, setEnrollments] = useState<any[]>([])
  const [certificates, setCertificates] = useState<any[]>([])
  const [stats, setStats] = useState({
    totalHoursLearned: 0,
    coursesCompleted: 0,
    coursesInProgress: 0,
    certificatesEarned: 0,
  })
  const [loading, setLoading] = useState(true)
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: currentUser },
      } = await supabase.auth.getUser()

      if (!currentUser) {
        router.push('/auth/login')
        return
      }

      setUser(currentUser)

      // Get profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentUser.id)
        .single()

      setProfile(profileData)

      // Get enrollments with course data
      const { data: enrollmentsData } = await supabase
        .from('enrollments')
        .select(`
          *,
          course:courses(id, title, thumbnail_url, description, duration_hours, rating, total_students)
        `)
        .eq('user_id', currentUser.id)
        .order('enrolled_at', { ascending: false })

      setEnrollments(enrollmentsData || [])

      // Get certificates
      const { data: certificatesData } = await supabase
        .from('certificates')
        .select(`
          *,
          course:courses(id, title)
        `)
        .eq('user_id', currentUser.id)

      setCertificates(certificatesData || [])

      // Calculate stats
      const completedCount = enrollmentsData?.filter(e => e.completed).length || 0
      const inProgressCount = (enrollmentsData?.length || 0) - completedCount
      const totalHours = enrollmentsData?.reduce((sum, e) => sum + (e.course?.duration_hours || 0), 0) || 0

      setStats({
        totalHoursLearned: totalHours,
        coursesCompleted: completedCount,
        coursesInProgress: inProgressCount,
        certificatesEarned: certificatesData?.length || 0,
      })

      // Mock chart data for learning activity
      setChartData([
        { day: 'Mon', hours: 2 },
        { day: 'Tue', hours: 3 },
        { day: 'Wed', hours: 1 },
        { day: 'Thu', hours: 4 },
        { day: 'Fri', hours: 2 },
        { day: 'Sat', hours: 5 },
        { day: 'Sun', hours: 1 },
      ])

      setLoading(false)
    }

    fetchData()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Loading dashboard...</p>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-12">
        <div className="container mx-auto max-w-6xl px-4">
          {/* Welcome section */}
          <div className="mb-12">
            <h1 className="text-4xl font-bold mb-2">Welcome back, {profile?.full_name || 'Learner'}!</h1>
            <p className="text-lg text-muted-foreground">
              Continue your learning journey and master new skills.
            </p>
          </div>

          {/* Stats cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <StatsCard
              icon={<Clock className="h-6 w-6" />}
              label="Total Hours"
              value={stats.totalHoursLearned}
              color="from-primary"
            />
            <StatsCard
              icon={<BookOpen className="h-6 w-6" />}
              label="In Progress"
              value={stats.coursesInProgress}
              color="from-blue-500"
            />
            <StatsCard
              icon={<TrendingUp className="h-6 w-6" />}
              label="Completed"
              value={stats.coursesCompleted}
              color="from-green-500"
            />
            <StatsCard
              icon={<Award className="h-6 w-6" />}
              label="Certificates"
              value={stats.certificatesEarned}
              color="from-accent"
            />
          </div>

          {/* Main content grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {/* Learning activity chart */}
            <div className="lg:col-span-2">
              <Card className="bg-card/50 border-border/40 p-8">
                <h2 className="text-2xl font-bold mb-6">Learning Activity</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="day" stroke="rgba(255,255,255,0.5)" />
                    <YAxis stroke="rgba(255,255,255,0.5)" />
                    <Tooltip
                      contentStyle={{ background: 'rgba(20, 20, 30, 0.95)', border: '1px solid rgba(255,255,255,0.1)' }}
                      cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                    />
                    <Bar dataKey="hours" fill="url(#colorBar)" radius={[8, 8, 0, 0]} />
                    <defs>
                      <linearGradient id="colorBar" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.8} />
                        <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.8} />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* Quick actions */}
            <div>
              <Card className="bg-gradient-to-br from-primary/20 to-accent/20 border-primary/40 p-8 mb-6">
                <h3 className="text-lg font-bold mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button className="w-full bg-primary hover:bg-primary/90 justify-start" asChild>
                    <Link href="/catalog">
                      <Plus className="h-4 w-4 mr-2" />
                      Explore Courses
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Award className="h-4 w-4 mr-2" />
                    View Certificates
                  </Button>
                </div>
              </Card>

          {/* Recommendations */}
            <Recommendations userId={user?.id} limit={3} showHeader={true} />
            </div>
          </div>

          {/* Enrolled courses */}
          {enrollments.length > 0 && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6">My Courses</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {enrollments.map((enrollment) => (
                  <CourseCard key={enrollment.id} enrollment={enrollment} />
                ))}
              </div>
            </div>
          )}

          {/* Empty state */}
          {enrollments.length === 0 && (
            <Card className="bg-card/50 border-border/40 p-12 text-center">
              <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-2xl font-bold mb-2">No courses yet</h3>
              <p className="text-muted-foreground mb-6">
                Explore our catalog and start learning today!
              </p>
              <Button className="bg-primary hover:bg-primary/90" asChild>
                <Link href="/catalog">Browse Courses</Link>
              </Button>
            </Card>
          )}

          {/* Certificates section */}
          {certificates.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold mb-6">My Certificates</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {certificates.map((cert) => (
                  <Card key={cert.id} className="bg-gradient-to-br from-accent/20 to-primary/20 border-accent/40 p-8">
                    <div className="flex items-start justify-between mb-4">
                      <Award className="h-8 w-8 text-accent flex-shrink-0" />
                      <span className="text-xs font-mono text-muted-foreground">{cert.certificate_number}</span>
                    </div>
                    <h3 className="text-xl font-bold mb-2">{cert.course?.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Issued on {new Date(cert.issued_at).toLocaleDateString()}
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      Download Certificate
                    </Button>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function StatsCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode
  label: string
  value: number
  color: string
}) {
  return (
    <Card className={`bg-gradient-to-br ${color}/20 to-transparent border-${color}/40 p-6`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-muted-foreground text-sm mb-1">{label}</p>
          <p className="text-3xl font-bold">{value}</p>
        </div>
        <div className="h-12 w-12 rounded-lg bg-background/50 flex items-center justify-center text-primary">
          {icon}
        </div>
      </div>
    </Card>
  )
}

function CourseCard({ enrollment }: { enrollment: any }) {
  const progress = enrollment.progress || 0
  const isCompleted = enrollment.completed

  return (
    <Link href={`/course/${enrollment.course?.id}/learn`}>
      <Card className="bg-card/50 border-border/40 hover:bg-card/80 hover:border-primary/30 transition-all overflow-hidden h-full flex flex-col cursor-pointer">
        {/* Thumbnail */}
        <div className="h-40 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center relative">
          <BookOpen className="h-12 w-12 text-primary/30" />
          {isCompleted && (
            <div className="absolute inset-0 bg-green-500/20 flex items-center justify-center">
              <Award className="h-8 w-8 text-green-400" />
            </div>
          )}
        </div>

        <div className="p-4 flex-grow flex flex-col">
          <h3 className="font-semibold text-base mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {enrollment.course?.title}
          </h3>

          <p className="text-sm text-muted-foreground mb-4 flex-grow line-clamp-2">
            {enrollment.course?.description}
          </p>

          {/* Progress bar */}
          <div className="mb-4">
            <div className="w-full bg-card rounded-full h-2 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {Math.round(progress)}% complete
            </p>
          </div>

          {/* Button */}
          <Button
            size="sm"
            className="w-full"
            variant={isCompleted ? 'outline' : 'default'}
          >
            {isCompleted ? (
              <>
                <Award className="h-4 w-4 mr-2" />
                Completed
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-2" />
                Continue
              </>
            )}
          </Button>
        </div>
      </Card>
    </Link>
  )
}
