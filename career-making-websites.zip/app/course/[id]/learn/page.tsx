'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import { Check, ChevronLeft, ChevronRight, Clock, Play } from 'lucide-react'
import Link from 'next/link'

export default function LearnPage() {
  const params = useParams()
  const router = useRouter()
  const courseId = params.id as string

  const [course, setCourse] = useState<any>(null)
  const [lessons, setLessons] = useState<any[]>([])
  const [currentLessonId, setCurrentLessonId] = useState<string | null>(null)
  const [currentLesson, setCurrentLesson] = useState<any>(null)
  const [enrollment, setEnrollment] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [lessonProgress, setLessonProgress] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [watchedPercentage, setWatchedPercentage] = useState(0)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: currentUser },
      } = await supabase.auth.getUser()

      if (!currentUser) {
        router.push('/auth/login')
        return
      }

      setUser(currentUser)

      // Fetch course
      const { data: courseData } = await supabase
        .from('courses')
        .select('*')
        .eq('id', courseId)
        .eq('is_published', true)
        .single()

      if (!courseData) {
        router.push('/catalog')
        return
      }

      setCourse(courseData)

      // Check enrollment
      const { data: enrollmentData } = await supabase
        .from('enrollments')
        .select('*')
        .eq('user_id', currentUser.id)
        .eq('course_id', courseId)
        .single()

      if (!enrollmentData) {
        router.push(`/course/${courseId}`)
        return
      }

      setEnrollment(enrollmentData)

      // Fetch lessons
      const { data: lessonsData } = await supabase
        .from('lessons')
        .select('*')
        .eq('course_id', courseId)
        .order('lesson_number', { ascending: true })

      setLessons(lessonsData || [])

      // Set first uncompleted lesson as current
      if (lessonsData && lessonsData.length > 0) {
        const firstLesson = lessonsData[0]
        setCurrentLessonId(firstLesson.id)
        setCurrentLesson(firstLesson)

        // Load lesson progress
        const { data: progressData } = await supabase
          .from('lesson_progress')
          .select('*')
          .eq('user_id', currentUser.id)
          .eq('lesson_id', firstLesson.id)
          .single()

        setLessonProgress(progressData || null)
      }

      setLoading(false)
    }

    fetchData()
  }, [courseId, router])

  const handleLessonClick = async (lessonId: string) => {
    setCurrentLessonId(lessonId)
    const lesson = lessons.find(l => l.id === lessonId)
    setCurrentLesson(lesson)
    setWatchedPercentage(0)

    // Load lesson progress
    const supabase = createClient()
    const { data: progressData } = await supabase
      .from('lesson_progress')
      .select('*')
      .eq('user_id', user.id)
      .eq('lesson_id', lessonId)
      .single()

    setLessonProgress(progressData || null)
  }

  const handleMarkComplete = async () => {
    const supabase = createClient()

    const { error } = await supabase.from('lesson_progress').upsert({
      user_id: user.id,
      lesson_id: currentLessonId,
      completed: true,
      watched_percentage: 100,
      completed_at: new Date().toISOString(),
    })

    if (!error) {
      setLessonProgress({
        ...lessonProgress,
        completed: true,
        watched_percentage: 100,
      })

      // Update enrollment progress
      const completedCount = lessons.filter(l => l.id !== currentLessonId).length + 1
      const progress = (completedCount / lessons.length) * 100

      await supabase
        .from('enrollments')
        .update({ progress })
        .eq('id', enrollment.id)

      // Check if course is completed
      if (progress >= 100) {
        await completeCourse()
      }
    }
  }

  const completeCourse = async () => {
    const supabase = createClient()

    // Update enrollment as completed
    await supabase
      .from('enrollments')
      .update({
        completed: true,
        completed_at: new Date().toISOString(),
        progress: 100,
      })
      .eq('id', enrollment.id)

    // Create certificate
    const certificateNumber = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    await supabase.from('certificates').insert({
      user_id: user.id,
      course_id: courseId,
      certificate_number: certificateNumber,
    })
  }

  const handleVideoProgress = (percentage: number) => {
    setWatchedPercentage(percentage)

    // Update progress in DB if watched significantly
    if (percentage > 50 && (!lessonProgress || lessonProgress.watched_percentage < 50)) {
      const supabase = createClient()
      supabase.from('lesson_progress').upsert({
        user_id: user.id,
        lesson_id: currentLessonId,
        watched_percentage: percentage,
      })
    }
  }

  const handleNextLesson = () => {
    const currentIndex = lessons.findIndex(l => l.id === currentLessonId)
    if (currentIndex < lessons.length - 1) {
      handleLessonClick(lessons[currentIndex + 1].id)
    }
  }

  const handlePreviousLesson = () => {
    const currentIndex = lessons.findIndex(l => l.id === currentLessonId)
    if (currentIndex > 0) {
      handleLessonClick(lessons[currentIndex - 1].id)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-20 pb-12">
          <p className="text-muted-foreground">Loading course...</p>
        </main>
      </div>
    )
  }

  if (!course || !currentLesson) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-20 pb-12">
          <p className="text-muted-foreground">Course not found</p>
        </main>
      </div>
    )
  }

  const currentIndex = lessons.findIndex(l => l.id === currentLessonId)
  const completedLessons = lessons.filter(l => l.completed).length
  const progress = (currentIndex / lessons.length) * 100

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-20 pb-12">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main video player area */}
            <div className="lg:col-span-2">
              {/* Back to course button */}
              <Link href={`/course/${courseId}`} className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6 transition-colors">
                <ChevronLeft className="h-4 w-4" />
                Back to course
              </Link>

              {/* Course header */}
              <div className="mb-6">
                <h1 className="text-3xl font-bold mb-2">{course.title}</h1>
                <div className="flex items-center gap-4 text-muted-foreground text-sm">
                  <span>{currentIndex + 1} of {lessons.length} lessons</span>
                  <span>•</span>
                  <span>{course.duration_hours} hours total</span>
                </div>
              </div>

              {/* Video Player */}
              <Card className="bg-card/50 border-border/40 overflow-hidden mb-8 aspect-video flex items-center justify-center">
                <div className="w-full h-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center relative">
                  <button
                    onClick={() => handleVideoProgress(75)}
                    className="group relative z-10"
                  >
                    <div className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90 flex items-center justify-center transition-all group-hover:scale-110">
                      <Play className="h-6 w-6 text-primary-foreground ml-1" fill="currentColor" />
                    </div>
                  </button>
                  <div className="absolute top-4 right-4 text-xs font-semibold px-3 py-1 rounded-full bg-primary/20 text-primary">
                    {currentLesson.video_duration_seconds
                      ? `${Math.round(currentLesson.video_duration_seconds / 60)} min`
                      : 'Demo'}
                  </div>
                </div>
              </Card>

              {/* Video progress bar */}
              <div className="mb-8">
                <div className="w-full bg-card rounded-full h-1 overflow-hidden mb-2">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                    style={{ width: `${watchedPercentage}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{Math.round(watchedPercentage)}% watched</span>
                  <span>{currentLesson.video_duration_seconds ? `${Math.round((watchedPercentage / 100) * currentLesson.video_duration_seconds / 60)} / ${Math.round(currentLesson.video_duration_seconds / 60)} min` : 'Video Demo'}</span>
                </div>
              </div>

              {/* Lesson content */}
              <Card className="bg-card/50 border-border/40 p-8 mb-8">
                <h2 className="text-2xl font-bold mb-4">{currentLesson.title}</h2>
                <p className="text-muted-foreground mb-6">{currentLesson.description}</p>

                {currentLesson.content && (
                  <div className="prose prose-invert max-w-none">
                    {currentLesson.content}
                  </div>
                )}
              </Card>

              {/* Lesson actions */}
              <div className="flex gap-4 mb-8">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handlePreviousLesson}
                  disabled={currentIndex === 0}
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>

                {!lessonProgress?.completed ? (
                  <Button
                    className="flex-1 bg-accent hover:bg-accent/90"
                    onClick={handleMarkComplete}
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Mark as Complete
                  </Button>
                ) : (
                  <Button
                    className="flex-1 bg-green-600/20 text-green-400 hover:bg-green-600/30"
                    disabled
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Completed
                  </Button>
                )}

                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleNextLesson}
                  disabled={currentIndex === lessons.length - 1}
                >
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              </div>

              {/* Discussion section preview */}
              <Card className="bg-card/50 border-border/40 p-8">
                <h3 className="text-xl font-bold mb-4">Questions & Discussion</h3>
                <p className="text-muted-foreground mb-4">
                  Have questions about this lesson? Ask the instructor and other students in the discussion forum.
                </p>
                <Button variant="outline">
                  Open Discussions
                </Button>
              </Card>
            </div>

            {/* Sidebar: Lessons list */}
            <div className="lg:col-span-1">
              {/* Course progress */}
              <Card className="bg-card/50 border-border/40 p-6 mb-6">
                <h3 className="text-lg font-bold mb-4">Course Progress</h3>
                <div className="mb-4">
                  <div className="w-full bg-card rounded-full h-2 overflow-hidden mb-2">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {currentIndex + 1} of {lessons.length} lessons
                  </p>
                </div>
              </Card>

              {/* Lessons list */}
              <div>
                <h3 className="text-lg font-bold mb-4">Course Content</h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {lessons.map((lesson, index) => {
                    const isCompleted = lessonProgress?.completed
                    const isCurrent = lesson.id === currentLessonId

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => handleLessonClick(lesson.id)}
                        className={`w-full text-left p-4 rounded-lg transition-all ${
                          isCurrent
                            ? 'bg-primary/20 border-primary/40 border'
                            : isCompleted
                            ? 'bg-green-500/10 hover:bg-green-500/20'
                            : 'bg-card/50 hover:bg-card/80'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0 mt-1">
                            {isCompleted ? (
                              <Check className="h-5 w-5 text-green-400" />
                            ) : (
                              <span className="text-xs font-semibold text-muted-foreground">
                                {index + 1}
                              </span>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`font-medium truncate ${isCurrent ? 'text-primary' : ''}`}>
                              {lesson.title}
                            </p>
                            {lesson.video_duration_seconds && (
                              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {Math.round(lesson.video_duration_seconds / 60)} min
                              </p>
                            )}
                          </div>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
