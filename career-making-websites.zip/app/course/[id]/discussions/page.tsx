'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { MessageSquare, Send, Search, ChevronLeft } from 'lucide-react'

export default function DiscussionsPage() {
  const params = useParams()
  const router = useRouter()
  const courseId = params.id as string

  const [course, setCourse] = useState<any>(null)
  const [discussions, setDiscussions] = useState<any[]>([])
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [newTitle, setNewTitle] = useState('')
  const [newContent, setNewContent] = useState('')
  const [searching, setSearching] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: currentUser },
      } = await supabase.auth.getUser()

      if (!currentUser) {
        router.push('/auth/login')
        return
      }

      setUser(currentUser)

      // Fetch course
      const { data: courseData } = await supabase
        .from('courses')
        .select('*')
        .eq('id', courseId)
        .eq('is_published', true)
        .single()

      if (!courseData) {
        router.push('/catalog')
        return
      }

      setCourse(courseData)

      // Check enrollment
      const { data: enrollmentData } = await supabase
        .from('enrollments')
        .select('*')
        .eq('user_id', currentUser.id)
        .eq('course_id', courseId)
        .single()

      if (!enrollmentData) {
        router.push(`/course/${courseId}`)
        return
      }

      // Fetch discussions
      const { data: discussionsData } = await supabase
        .from('discussions')
        .select(`
          *,
          user:profiles(full_name, avatar_url),
          discussion_replies(count)
        `)
        .eq('course_id', courseId)
        .order('created_at', { ascending: false })

      setDiscussions(discussionsData || [])
      setLoading(false)
    }

    fetchData()
  }, [courseId, router])

  const handleCreateDiscussion = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newTitle.trim() || !newContent.trim()) {
      return
    }

    setSubmitting(true)
    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from('discussions')
        .insert({
          course_id: courseId,
          user_id: user.id,
          title: newTitle,
          content: newContent,
        })
        .select(`
          *,
          user:profiles(full_name, avatar_url),
          discussion_replies(count)
        `)
        .single()

      if (error) throw error

      setDiscussions([data, ...discussions])
      setNewTitle('')
      setNewContent('')
      setShowForm(false)
    } catch (error) {
      console.error('Error creating discussion:', error)
    } finally {
      setSubmitting(false)
    }
  }

  const filteredDiscussions = discussions.filter(d =>
    d.title.toLowerCase().includes(searching.toLowerCase()) ||
    d.content.toLowerCase().includes(searching.toLowerCase())
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Loading discussions...</p>
        </main>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12 px-4">
          <p className="text-muted-foreground">Course not found</p>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-12">
        <div className="container mx-auto max-w-4xl px-4">
          {/* Header */}
          <Link href={`/course/${courseId}`} className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-6 transition-colors">
            <ChevronLeft className="h-4 w-4" />
            Back to course
          </Link>

          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Course Discussions</h1>
            <p className="text-lg text-muted-foreground">
              Ask questions and discuss with other students learning {course.title}
            </p>
          </div>

          {/* Search bar */}
          <div className="relative mb-8">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search discussions..."
              value={searching}
              onChange={(e) => setSearching(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-lg bg-card border border-border/40 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50"
            />
          </div>

          {/* New discussion form */}
          {!showForm ? (
            <Button
              className="w-full mb-8 bg-primary hover:bg-primary/90 justify-start h-12"
              onClick={() => setShowForm(true)}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Start a New Discussion
            </Button>
          ) : (
            <Card className="bg-card/50 border-border/40 p-6 mb-8">
              <form onSubmit={handleCreateDiscussion}>
                <div className="mb-4">
                  <label className="text-sm font-semibold block mb-2">Topic</label>
                  <input
                    type="text"
                    placeholder="What's your question or topic?"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg bg-background border border-border/40 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="text-sm font-semibold block mb-2">Message</label>
                  <textarea
                    placeholder="Share more details about your question..."
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    rows={4}
                    className="w-full px-4 py-2 rounded-lg bg-background border border-border/40 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50 resize-none"
                    required
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    type="submit"
                    className="flex-1 bg-primary hover:bg-primary/90"
                    disabled={submitting || !newTitle.trim() || !newContent.trim()}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {submitting ? 'Posting...' : 'Post Discussion'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setShowForm(false)
                      setNewTitle('')
                      setNewContent('')
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          )}

          {/* Discussions list */}
          <div className="space-y-4">
            {filteredDiscussions.length === 0 ? (
              <Card className="bg-card/50 border-border/40 p-12 text-center">
                <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">
                  {discussions.length === 0 ? 'No discussions yet. Be the first to ask!' : 'No results found'}
                </p>
              </Card>
            ) : (
              filteredDiscussions.map((discussion) => (
                <DiscussionCard key={discussion.id} discussion={discussion} courseId={courseId} />
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

function DiscussionCard({ discussion, courseId }: { discussion: any; courseId: string }) {
  const repliesCount = discussion.discussion_replies?.[0]?.count || 0
  const postedDate = new Date(discussion.created_at).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })

  return (
    <Link href={`/course/${courseId}/discussions/${discussion.id}`}>
      <Card className="bg-card/50 border-border/40 p-6 hover:bg-card/80 hover:border-primary/30 transition-all cursor-pointer">
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-semibold text-primary flex-shrink-0">
            {discussion.user?.full_name?.[0]?.toUpperCase()}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-base mb-1 group-hover:text-primary transition-colors line-clamp-1">
              {discussion.title}
            </h3>
            <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
              {discussion.content}
            </p>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>{discussion.user?.full_name}</span>
              <span>•</span>
              <span>{postedDate}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <MessageSquare className="h-3 w-3" />
                {repliesCount} replies
              </span>
            </div>
          </div>

          {/* Reply count badge */}
          {repliesCount > 0 && (
            <div className="h-8 w-8 rounded-full bg-accent/20 flex items-center justify-center text-xs font-bold text-accent flex-shrink-0">
              {repliesCount > 9 ? '9+' : repliesCount}
            </div>
          )}
        </div>
      </Card>
    </Link>
  )
}
