'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { Star, Users, Clock, CheckCircle, Zap, Award, MessageSquare } from 'lucide-react'

export default function CourseDetailPage() {
  const params = useParams()
  const router = useRouter()
  const courseId = params.id as string

  const [course, setCourse] = useState<any>(null)
  const [lessons, setLessons] = useState<any[]>([])
  const [reviews, setReviews] = useState<any[]>([])
  const [enrollment, setEnrollment] = useState<any>(null)
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [enrolling, setEnrolling] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()

      // Get current user
      const {
        data: { user: currentUser },
      } = await supabase.auth.getUser()
      setUser(currentUser)

      // Fetch course
      const { data: courseData, error: courseError } = await supabase
        .from('courses')
        .select(`
          *,
          instructor:instructors(id, bio, avatar_url, title, verified, total_students, rating)
        `)
        .eq('id', courseId)
        .eq('is_published', true)
        .single()

      if (courseError) {
        console.error('Error fetching course:', courseError)
        return
      }

      setCourse(courseData)

      // Fetch lessons
      const { data: lessonsData } = await supabase
        .from('lessons')
        .select('*')
        .eq('course_id', courseId)
        .order('lesson_number', { ascending: true })

      setLessons(lessonsData || [])

      // Fetch reviews
      const { data: reviewsData } = await supabase
        .from('reviews')
        .select(`
          *,
          user:profiles(full_name, avatar_url)
        `)
        .eq('course_id', courseId)
        .order('created_at', { ascending: false })

      setReviews(reviewsData || [])

      // Check enrollment
      if (currentUser) {
        const { data: enrollmentData } = await supabase
          .from('enrollments')
          .select('*')
          .eq('user_id', currentUser.id)
          .eq('course_id', courseId)
          .single()

        setEnrollment(enrollmentData || null)
      }

      setLoading(false)
    }

    fetchData()
  }, [courseId])

  const handleEnroll = async () => {
    if (!user) {
      router.push('/auth/sign-up')
      return
    }

    setEnrolling(true)
    const supabase = createClient()

    try {
      const { data, error } = await supabase
        .from('enrollments')
        .insert({
          user_id: user.id,
          course_id: courseId,
        })
        .select()
        .single()

      if (error) throw error

      setEnrollment(data)
      router.push(`/course/${courseId}/learn`)
    } catch (error) {
      console.error('Error enrolling:', error)
    } finally {
      setEnrolling(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12">
          <div className="container mx-auto max-w-4xl px-4">
            <p className="text-muted-foreground">Loading course...</p>
          </div>
        </main>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-24 pb-12">
          <div className="container mx-auto max-w-4xl px-4">
            <p className="text-muted-foreground">Course not found</p>
          </div>
        </main>
      </div>
    )
  }

  const avgRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '0.0'

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="pt-24 pb-12">
        <section className="px-4 mb-12">
          <div className="container mx-auto max-w-4xl">
            {/* Hero section */}
            <div className="mb-8">
              <div className="h-80 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg mb-8 flex items-center justify-center">
                <div className="text-7xl opacity-20">📚</div>
              </div>

              <div className="mb-6">
                <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
                <p className="text-xl text-muted-foreground mb-6">{course.description}</p>

                {/* Stats */}
                <div className="flex flex-wrap gap-6 mb-8 text-sm">
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 fill-accent text-accent" />
                    <span className="font-semibold">{avgRating}</span>
                    <span className="text-muted-foreground">({reviews.length} reviews)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    <span className="font-semibold">{course.total_students?.toLocaleString() || '0'}</span>
                    <span className="text-muted-foreground">students</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    <span className="font-semibold">{course.duration_hours || '0'}</span>
                    <span className="text-muted-foreground">hours</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-semibold px-3 py-1 rounded-full text-xs ${
                      course.level === 'Beginner'
                        ? 'bg-green-500/20 text-green-400'
                        : course.level === 'Intermediate'
                        ? 'bg-yellow-500/20 text-yellow-400'
                        : 'bg-red-500/20 text-red-400'
                    }`}>
                      {course.level}
                    </span>
                  </div>
                </div>

                {/* Instructor */}
                <div className="flex items-center gap-4 pb-8 border-b border-border/40">
                  <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center font-semibold text-primary">
                    {course.instructor?.title?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold">{course.instructor?.title}</p>
                    {course.instructor?.verified && (
                      <p className="text-sm text-accent">✓ Verified Instructor</p>
                    )}
                    <p className="text-sm text-muted-foreground">
                      {course.instructor?.total_students?.toLocaleString() || '0'} students
                    </p>
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              {!enrollment ? (
                <Button
                  size="lg"
                  className="w-full bg-primary hover:bg-primary/90 text-lg h-12"
                  onClick={handleEnroll}
                  disabled={enrolling}
                >
                  {enrolling ? 'Enrolling...' : 'Enroll Now'}
                </Button>
              ) : (
                <Button
                  size="lg"
                  className="w-full bg-accent hover:bg-accent/90 text-lg h-12"
                  asChild
                >
                  <Link href={`/course/${courseId}/learn`}>
                    Continue Learning
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </section>

        {/* Content sections */}
        <section className="px-4">
          <div className="container mx-auto max-w-4xl space-y-12">
            {/* What you'll learn */}
            <Card className="bg-card/50 border-border/40 p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <Zap className="h-6 w-6 text-accent" />
                What You&apos;ll Learn
              </h2>
              <ul className="grid md:grid-cols-2 gap-4">
                {[
                  'Master core concepts and fundamentals',
                  'Build real-world projects',
                  'Learn best practices and industry standards',
                  'Gain hands-on experience',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Course content */}
            <Card className="bg-card/50 border-border/40 p-8">
              <h2 className="text-2xl font-bold mb-6">Course Content</h2>
              <p className="text-muted-foreground mb-6">
                {lessons.length} lessons • {course.duration_hours || 0} hours
              </p>
              <div className="space-y-2">
                {lessons.map((lesson, index) => (
                  <div
                    key={lesson.id}
                    className="flex items-center gap-4 p-4 rounded-lg bg-background/50 hover:bg-background transition-colors"
                  >
                    <span className="text-sm font-semibold text-muted-foreground w-8">
                      {lesson.lesson_number}
                    </span>
                    <div className="flex-1">
                      <p className="font-medium">{lesson.title}</p>
                      {lesson.video_duration_seconds && (
                        <p className="text-sm text-muted-foreground">
                          {Math.round(lesson.video_duration_seconds / 60)} minutes
                        </p>
                      )}
                    </div>
                    {enrollment && <CheckCircle className="h-5 w-5 text-green-400" />}
                  </div>
                ))}
              </div>
            </Card>

            {/* Reviews */}
            <Card className="bg-card/50 border-border/40 p-8">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <MessageSquare className="h-6 w-6 text-primary" />
                Student Reviews ({reviews.length})
              </h2>
              <div className="space-y-6">
                {reviews.slice(0, 5).map((review) => (
                  <div key={review.id} className="pb-6 border-b border-border/40 last:border-b-0 last:pb-0">
                    <div className="flex items-start gap-4 mb-2">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary flex-shrink-0">
                        {review.user?.full_name?.[0]?.toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold">{review.user?.full_name}</p>
                        <div className="flex items-center gap-2">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < review.rating
                                  ? 'fill-accent text-accent'
                                  : 'text-muted-foreground'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    {review.title && <p className="font-medium mb-2">{review.title}</p>}
                    <p className="text-muted-foreground">{review.comment}</p>
                  </div>
                ))}
              </div>
            </Card>

            {/* Certificate */}
            <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border-primary/40 p-8">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-3">
                <Award className="h-6 w-6 text-accent" />
                Get Certified
              </h2>
              <p className="text-muted-foreground mb-4">
                Complete this course and earn a recognized certificate to showcase your achievement.
              </p>
              <Button variant="outline" className="border-primary/40 hover:bg-primary/10">
                Learn more about certificates
              </Button>
            </Card>
          </div>
        </section>
      </main>
    </div>
  )
}
