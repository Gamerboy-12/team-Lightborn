'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'
import { Star, Users, Clock, Search } from 'lucide-react'

export default function CatalogPage() {
  const [courses, setCourses] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedLevel, setSelectedLevel] = useState('All')

  const categories = ['All', 'Technology', 'Business', 'Creative', 'Development', 'Data Science', 'Design']
  const levels = ['All', 'Beginner', 'Intermediate', 'Advanced']

  useEffect(() => {
    const fetchCourses = async () => {
      const supabase = createClient()
      let query = supabase
        .from('courses')
        .select(`
          *,
          instructor:instructors(id, bio, avatar_url, title, verified)
        `)
        .eq('is_published', true)

      if (selectedCategory !== 'All') {
        query = query.eq('category', selectedCategory)
      }

      if (selectedLevel !== 'All') {
        query = query.eq('level', selectedLevel)
      }

      const { data, error } = await query.order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching courses:', error)
      } else {
        const filtered = data?.filter(course =>
          course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.description?.toLowerCase().includes(searchTerm.toLowerCase())
        ) || []
        setCourses(filtered)
      }
      setLoading(false)
    }

    fetchCourses()
  }, [selectedCategory, selectedLevel, searchTerm])

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24 pb-12">
        {/* Hero section */}
        <section className="px-4 mb-12">
          <div className="container mx-auto max-w-6xl">
            <h1 className="text-4xl font-bold mb-4">Explore Courses</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Discover thousands of expert-led courses across all subjects and skill levels
            </p>

            {/* Search bar */}
            <div className="relative mb-8">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search courses by name or topic..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-card border border-border/40 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          </div>
        </section>

        <section className="px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid lg:grid-cols-4 gap-8">
              {/* Filters sidebar */}
              <aside className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                  {/* Category filter */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Category</h3>
                    <div className="space-y-2">
                      {categories.map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategory(cat)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                            selectedCategory === cat
                              ? 'bg-primary/20 text-primary font-semibold'
                              : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Level filter */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Level</h3>
                    <div className="space-y-2">
                      {levels.map((level) => (
                        <button
                          key={level}
                          onClick={() => setSelectedLevel(level)}
                          className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                            selectedLevel === level
                              ? 'bg-primary/20 text-primary font-semibold'
                              : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </aside>

              {/* Courses grid */}
              <div className="lg:col-span-3">
                {loading ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Loading courses...</p>
                  </div>
                ) : courses.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">No courses found matching your criteria.</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-6">
                    {courses.map((course) => (
                      <CourseCard key={course.id} course={course} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

function CourseCard({ course }: { course: any }) {
  return (
    <Link href={`/course/${course.id}`}>
      <Card className="bg-card/50 border-border/40 hover:bg-card/80 hover:border-primary/30 transition-all overflow-hidden group h-full flex flex-col cursor-pointer">
        {/* Course thumbnail */}
        <div className="relative h-40 bg-gradient-to-br from-primary/20 to-accent/20 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center text-4xl opacity-10">
            📚
          </div>
        </div>

        <div className="p-4 flex flex-col flex-grow">
          {/* Instructor info */}
          <div className="flex items-center gap-2 mb-3">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
              {course.instructor?.title?.[0]?.toUpperCase() || 'I'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-primary truncate">
                {course.instructor?.title || 'Instructor'}
              </p>
              {course.instructor?.verified && (
                <span className="text-xs text-accent">✓ Verified</span>
              )}
            </div>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-base mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {course.title}
          </h3>

          {/* Description */}
          <p className="text-sm text-muted-foreground mb-4 flex-grow line-clamp-2">
            {course.description}
          </p>

          {/* Stats */}
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-accent text-accent" />
              <span>{course.rating?.toFixed(1) || '0.0'}</span>
              <span>({course.total_reviews || 0})</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{course.total_students?.toLocaleString() || '0'}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{course.duration_hours || '0'}h</span>
            </div>
          </div>

          {/* Level badge */}
          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
              course.level === 'Beginner'
                ? 'bg-green-500/20 text-green-400'
                : course.level === 'Intermediate'
                ? 'bg-yellow-500/20 text-yellow-400'
                : 'bg-red-500/20 text-red-400'
            }`}>
              {course.level}
            </span>
            {course.price > 0 && (
              <span className="text-sm font-semibold ml-auto">${course.price?.toFixed(2)}</span>
            )}
            {course.price === 0 && (
              <span className="text-sm font-semibold ml-auto text-accent">Free</span>
            )}
          </div>
        </div>
      </Card>
    </Link>
  )
}
