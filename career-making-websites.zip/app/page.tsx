'use client'

import React from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { ParticleNetworkBackground } from '@/components/particle-network-background'
import {
  Play,
  Star,
  Users,
  Award,
  Zap,
  TrendingUp,
} from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black relative">
      <ParticleNetworkBackground />

      <div className="relative z-10">
        {/* Header */}
        <header className="fixed top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-xl">
          <div className="container mx-auto flex h-16 items-center justify-between px-4">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Play
                  className="h-5 w-5 text-primary-foreground"
                  fill="currentColor"
                />
              </div>

              <span className="text-xl font-bold">
                EduStream
              </span>
            </div>

            <nav className="hidden items-center gap-8 md:flex">
              <a
                href="#features"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Features
              </a>

              <a
                href="#courses"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Courses
              </a>

              <a
                href="#instructors"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Instructors
              </a>
            </nav>

            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/auth/login">
                  Sign In
                </Link>
              </Button>

              <Button
                size="sm"
                asChild
                className="bg-primary hover:bg-primary/90"
              >
                <Link href="/auth/sign-up">
                  Get Started
                </Link>
              </Button>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="pt-32 pb-20 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <div className="inline-block mb-6 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-sm font-medium text-primary">
              ✨ Welcome to the Future of Learning
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Stream Unlimited{' '}
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                Learning
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-muted-foreground mb-8 leading-relaxed">
              Learn from the world&apos;s best educators.
              Master new skills. Build your future.
              All in one platform.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-lg h-12 px-8"
                asChild
              >
                <Link href="/auth/sign-up">
                  Start Free Trial
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="text-lg h-12 px-8"
              >
                Explore Courses
              </Button>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-primary">
                  10K+
                </div>

                <p className="text-muted-foreground mt-1">
                  Expert Courses
                </p>
              </div>

              <div>
                <div className="text-3xl font-bold text-primary">
                  500K+
                </div>

                <p className="text-muted-foreground mt-1">
                  Active Learners
                </p>
              </div>

              <div>
                <div className="text-3xl font-bold text-primary">
                  4.9★
                </div>

                <p className="text-muted-foreground mt-1">
                  Average Rating
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section
          id="features"
          className="py-20 px-4 border-t border-border/40"
        >
          <div className="container mx-auto max-w-6xl">
            <h2 className="text-4xl font-bold mb-4 text-center">
              Why Choose EduStream?
            </h2>

            <p className="text-center text-muted-foreground mb-16 text-lg">
              Everything you need to learn, grow,
              and succeed
            </p>

            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Play className="h-6 w-6" />}
                title="Premium Video Courses"
                description="Learn from industry experts with HD video content, downloadable resources, and lifetime access."
              />

              <FeatureCard
                icon={<Users className="h-6 w-6" />}
                title="Community & Discussions"
                description="Connect with fellow learners, ask questions, share insights, and grow together."
              />

              <FeatureCard
                icon={<Award className="h-6 w-6" />}
                title="Recognized Certificates"
                description="Earn shareable certificates upon completion to showcase your achievements."
              />

              <FeatureCard
                icon={<Zap className="h-6 w-6" />}
                title="Personalized Learning"
                description="AI-powered recommendations tailored to your learning goals and interests."
              />

              <FeatureCard
                icon={<TrendingUp className="h-6 w-6" />}
                title="Progress Tracking"
                description="Monitor your learning journey with detailed analytics and performance insights."
              />

              <FeatureCard
                icon={<Star className="h-6 w-6" />}
                title="Expert Instructors"
                description="Learn from verified experts with real-world experience in their fields."
              />
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl">
            <Card className="bg-gradient-to-r from-primary/20 to-accent/20 border-primary/40 p-12 text-center">
              <h2 className="text-4xl font-bold mb-4">
                Ready to Learn?
              </h2>

              <p className="text-lg text-muted-foreground mb-8">
                Join thousands of students already
                learning on EduStream.
              </p>

              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-lg h-12 px-8"
                asChild
              >
                <Link href="/auth/sign-up">
                  Sign Up Free
                </Link>
              </Button>
            </Card>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border/40 py-12 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-4 gap-8 mb-8">
              <div>
                <h3 className="font-semibold mb-4">
                  Product
                </h3>

                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>Features</li>
                  <li>Pricing</li>
                  <li>Security</li>
                </ul>
              </div>
            </div>

            <div className="border-t border-border/40 pt-8 text-center text-sm text-muted-foreground">
              <p>
                &copy; 2024 EduStream.
                All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}

type FeatureCardProps = {
  icon: React.ReactNode
  title: string
  description: string
}

function FeatureCard({
  icon,
  title,
  description,
}: FeatureCardProps) {
  return (
    <Card className="bg-card/50 border-border/40 p-6 hover:bg-card/80 hover:border-primary/30 transition-all group">
      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 text-primary group-hover:bg-primary/20 transition-colors">
        {icon}
      </div>

      <h3 className="text-xl font-semibold mb-2">
        {title}
      </h3>

      <p className="text-muted-foreground">
        {description}
      </p>
    </Card>
  )
}