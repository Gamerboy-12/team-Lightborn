import useSWR from 'swr'
import { getCourses, getCourseById, getUserEnrollments } from '@/lib/db'

const fetcher = async (key: string) => {
  if (key === 'all-courses') {
    return getCourses()
  }
  return null
}

export function useAllCourses() {
  const { data, error, isLoading } = useSWR('all-courses', fetcher)
  
  return {
    courses: data,
    isLoading,
    isError: !!error,
    error,
  }
}

export function useCourse(courseId: string | null) {
  const { data, error, isLoading } = useSWR(
    courseId ? `course-${courseId}` : null,
    async () => courseId ? getCourseById(courseId) : null
  )
  
  return {
    course: data,
    isLoading,
    isError: !!error,
    error,
  }
}

export function useUserEnrollments(userId: string | null) {
  const { data, error, isLoading } = useSWR(
    userId ? `enrollments-${userId}` : null,
    async () => userId ? getUserEnrollments(userId) : null
  )
  
  return {
    enrollments: data,
    isLoading,
    isError: !!error,
    error,
  }
}
