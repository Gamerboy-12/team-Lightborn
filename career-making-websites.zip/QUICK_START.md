# EduStream - Quick Start Guide

Get up and running with EduStream in 5 minutes!

## Prerequisites

- Node.js 18 or higher
- pnpm, npm, or yarn
- A Supabase project
- An OpenAI API key (optional, for AI recommendations)

## 1. Install Dependencies

```bash
pnpm install
```

## 2. Configure Environment Variables

Create a `.env.local` file in the root directory:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

Get these from your Supabase project settings.

## 3. Start the Development Server

```bash
pnpm dev
```

The app will be available at `http://localhost:3000`

## 4. Create Demo Data (Optional)

You can populate the database with sample courses and instructors:

1. Sign up at `http://localhost:3000/auth/sign-up`
2. Confirm your email (check terminal or Supabase dashboard)
3. Call the demo setup API:

```bash
curl -X POST http://localhost:3000/api/demo-setup
```

Or visit `/api/demo-setup` in the browser while logged in.

## 5. Explore the App

### Key Pages to Visit

- **Landing Page**: `http://localhost:3000` - Overview and call-to-action
- **Catalog**: `http://localhost:3000/catalog` - Browse and filter courses
- **Dashboard**: `http://localhost:3000/dashboard` - Your learning progress
- **Certificates**: `http://localhost:3000/certificates` - Your achievements

### Quick Actions

1. **Browse Courses**
   - Go to `/catalog`
   - Try filtering by category or difficulty
   - Click a course to see details

2. **Enroll in a Course**
   - Click "Enroll Now" on any course detail page
   - You'll be taken to the learning page

3. **Start Learning**
   - Watch lessons (demo video player)
   - Mark lessons as complete
   - Track your progress

4. **View Recommendations**
   - Go to `/dashboard`
   - Scroll down to see AI-powered recommendations
   - Enroll in more courses to get better suggestions

## Database Setup

The database schema is automatically created by Supabase:

```sql
-- 10 Tables:
- auth.users (Supabase managed)
- profiles
- instructors
- courses
- lessons
- enrollments
- lesson_progress
- certificates
- reviews
- discussions
- discussion_replies
```

All tables have Row Level Security (RLS) enabled for security.

## Project Structure

```
app/                    # Next.js App Router pages
├── page.tsx           # Landing page
├── auth/              # Authentication pages
├── catalog/           # Course browsing
├── course/            # Course detail & learning
├── dashboard/         # Student dashboard
├── certificates/      # Certificate management
├── instructor/        # Instructor profiles
├── api/               # API routes
└── layout.tsx         # Root layout

components/            # Reusable components
├── header.tsx
├── recommendations.tsx
└── ui/               # shadcn/ui components

lib/                   # Utilities & database
├── supabase/         # Supabase clients
├── db.ts             # Database functions
└── utils.ts          # Helper functions

hooks/                # React hooks
└── use-courses.ts    # SWR data fetching

scripts/              # Utilities
└── seed.ts           # Database seeding
```

## Common Tasks

### Add a New Course (Manual)

```sql
INSERT INTO public.courses (
  instructor_id, title, description, category, 
  level, duration_hours, price, is_published
) VALUES (
  'instructor-uuid', 'Course Title', 'Description',
  'Category', 'Beginner', 20, 49.99, true
);
```

### Customize the Theme

Edit `/app/globals.css` to change the color palette:

```css
:root {
  --primary: oklch(0.605 0.256 264.376);  /* Change these colors */
  --accent: oklch(0.729 0.242 31.736);
  /* ... */
}
```

### Deploy to Vercel

```bash
# Connect your GitHub repository
# Or push to a new repository

git push origin main
```

Then go to vercel.com and import your project.

## Troubleshooting

### "Unauthorized" errors

- Make sure you're logged in
- Check that your Supabase environment variables are correct
- Verify RLS policies are enabled in Supabase dashboard

### No courses appearing

- Run `/api/demo-setup` to create sample courses
- Check that courses have `is_published = true`
- Verify your Supabase RLS policies

### Authentication not working

- Confirm your email in Supabase Auth dashboard
- Check that `NEXT_PUBLIC_SUPABASE_URL` is correct
- Clear browser cookies and try again

### AI Recommendations not working

- Verify you have an OpenAI API key set up
- Check the `/api/recommendations` route is working
- Review the server logs for errors

## Next Steps

1. **Customize the branding** - Update logo, colors, and copy
2. **Add more courses** - Use the seed script or manual entry
3. **Set up payments** - Integrate Stripe for paid courses
4. **Configure email** - Set up email templates in Supabase
5. **Deploy to production** - Use Vercel or your preferred host

## Resources

- [README.md](./README.md) - Complete documentation
- [IMPLEMENTATION_GUIDE.md](./IMPLEMENTATION_GUIDE.md) - Architecture details
- [PROJECT_SUMMARY.md](./PROJECT_SUMMARY.md) - Project overview

## Need Help?

Check the documentation files or the code comments for detailed information.

---

**Happy learning! 🚀**
