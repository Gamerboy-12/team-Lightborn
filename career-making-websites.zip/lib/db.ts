import { createClient } from '@/lib/supabase/server'

// Profile operations
export async function getUserProfile(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  
  if (error) throw error
  return data
}

export async function updateUserProfile(userId: string, updates: any) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single()
  
  if (error) throw error
  return data
}

// Course operations
export async function getCourses(limit = 20) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('courses')
    .select(`
      *,
      instructor:instructors(id, bio, avatar_url, title, verified)
    `)
    .eq('is_published', true)
    .limit(limit)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data
}

export async function getCourseById(courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('courses')
    .select(`
      *,
      instructor:instructors(id, bio, avatar_url, title, verified, total_students),
      lessons:lessons(id, title, lesson_number, video_duration_seconds),
      reviews:reviews(id, rating, comment, created_at, user:profiles(full_name, avatar_url))
    `)
    .eq('id', courseId)
    .eq('is_published', true)
    .single()
  
  if (error) throw error
  return data
}

// Enrollment operations
export async function enrollInCourse(userId: string, courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('enrollments')
    .insert({
      user_id: userId,
      course_id: courseId,
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getUserEnrollments(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('enrollments')
    .select(`
      *,
      course:courses(id, title, thumbnail_url, description)
    `)
    .eq('user_id', userId)
  
  if (error) throw error
  return data
}

export async function getEnrollment(userId: string, courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('enrollments')
    .select('*')
    .eq('user_id', userId)
    .eq('course_id', courseId)
    .single()
  
  if (error && error.code !== 'PGRST116') throw error
  return data
}

// Lesson operations
export async function getCourseLessons(courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('course_id', courseId)
    .order('lesson_number', { ascending: true })
  
  if (error) throw error
  return data
}

export async function getLessonById(lessonId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('id', lessonId)
    .single()
  
  if (error) throw error
  return data
}

// Lesson progress operations
export async function updateLessonProgress(userId: string, lessonId: string, updates: any) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('lesson_progress')
    .upsert({
      user_id: userId,
      lesson_id: lessonId,
      ...updates,
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getUserLessonProgress(userId: string, lessonId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('lesson_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('lesson_id', lessonId)
    .single()
  
  if (error && error.code !== 'PGRST116') throw error
  return data || null
}

// Review operations
export async function createReview(userId: string, courseId: string, review: any) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('reviews')
    .insert({
      user_id: userId,
      course_id: courseId,
      ...review,
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getCourseReviews(courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      user:profiles(full_name, avatar_url)
    `)
    .eq('course_id', courseId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data
}

// Discussion operations
export async function createDiscussion(userId: string, courseId: string, discussion: any) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('discussions')
    .insert({
      user_id: userId,
      course_id: courseId,
      ...discussion,
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getCourseDiscussions(courseId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('discussions')
    .select(`
      *,
      user:profiles(full_name, avatar_url),
      discussion_replies(count)
    `)
    .eq('course_id', courseId)
    .order('created_at', { ascending: false })
  
  if (error) throw error
  return data
}

// Certificate operations
export async function createCertificate(userId: string, courseId: string) {
  const supabase = await createClient()
  const certificateNumber = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
  
  const { data, error } = await supabase
    .from('certificates')
    .insert({
      user_id: userId,
      course_id: courseId,
      certificate_number: certificateNumber,
    })
    .select()
    .single()
  
  if (error) throw error
  return data
}

export async function getUserCertificates(userId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('certificates')
    .select(`
      *,
      course:courses(id, title)
    `)
    .eq('user_id', userId)
  
  if (error) throw error
  return data
}

// Instructor operations
export async function getInstructors() {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('instructors')
    .select('*')
    .eq('verified', true)
    .order('total_students', { ascending: false })
  
  if (error) throw error
  return data
}

export async function getInstructorById(instructorId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('instructors')
    .select(`
      *,
      courses:courses(id, title, thumbnail_url, rating, total_students)
    `)
    .eq('id', instructorId)
    .single()
  
  if (error) throw error
  return data
}

export async function getInstructorCourses(instructorId: string) {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('instructor_id', instructorId)
    .eq('is_published', true)
  
  if (error) throw error
  return data
}
