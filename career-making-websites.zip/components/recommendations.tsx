'use client'

import { useEffect, useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Sparkles, Star, TrendingUp } from 'lucide-react'

export interface Recommendation {
  courseId: string
  courseTitle: string
  reason: string
  relevanceScore: number
}

interface RecommendationsProps {
  userId?: string
  limit?: number
  showHeader?: boolean
}

export function Recommendations({
  userId,
  limit = 4,
  showHeader = true,
}: RecommendationsProps) {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const response = await fetch('/api/recommendations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        })

        if (!response.ok) throw new Error('Failed to fetch recommendations')

        const data = await response.json()
        setRecommendations((data.recommendations || []).slice(0, limit))
      } catch (err) {
        console.error('Error fetching recommendations:', err)
        setError(err instanceof Error ? err.message : 'Unknown error')
      } finally {
        setLoading(false)
      }
    }

    fetchRecommendations()
  }, [userId, limit])

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(Math.min(3, limit))].map((_, i) => (
          <Card key={i} className="bg-card/50 border-border/40 p-4 animate-pulse">
            <div className="h-4 bg-muted rounded w-3/4 mb-3" />
            <div className="h-3 bg-muted rounded w-full" />
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <Card className="bg-destructive/10 border-destructive/40 p-4">
        <p className="text-sm text-destructive">Failed to load recommendations</p>
      </Card>
    )
  }

  if (recommendations.length === 0) {
    return (
      <Card className="bg-card/50 border-border/40 p-6 text-center">
        <p className="text-muted-foreground">
          Enroll in more courses to get personalized recommendations
        </p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {showHeader && (
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="h-5 w-5 text-accent" />
          <h3 className="text-lg font-bold">Recommended For You</h3>
        </div>
      )}

      <div className="space-y-3">
        {recommendations.map((rec) => (
          <Link
            key={rec.courseId}
            href={`/course/${rec.courseId}`}
            className="block group"
          >
            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/40 p-4 hover:bg-primary/20 hover:border-primary/60 transition-all cursor-pointer">
              <div className="flex items-start gap-4">
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm mb-2 group-hover:text-primary transition-colors line-clamp-1">
                    {rec.courseTitle}
                  </h4>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
                    {rec.reason}
                  </p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs">
                      <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-accent/20">
                        <TrendingUp className="h-3 w-3 text-accent" />
                        <span className="text-accent font-semibold">
                          {rec.relevanceScore}% match
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Relevance score indicator */}
                <div className="flex-shrink-0 flex flex-col items-center gap-1">
                  <div className="relative h-10 w-10">
                    <svg className="h-full w-full -rotate-90" viewBox="0 0 36 36">
                      <circle
                        cx="18"
                        cy="18"
                        r="15.5"
                        fill="none"
                        className="stroke-current text-card"
                        strokeWidth="3"
                      />
                      <circle
                        cx="18"
                        cy="18"
                        r="15.5"
                        fill="none"
                        className="stroke-current text-accent transition-all"
                        strokeWidth="3"
                        strokeDasharray={`${rec.relevanceScore * 0.97} 100`}
                      />
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center text-xs font-bold">
                      {rec.relevanceScore}
                    </span>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {recommendations.length > 0 && (
        <Button
          variant="outline"
          className="w-full border-primary/40 hover:bg-primary/10"
          asChild
        >
          <Link href="/catalog">
            <Sparkles className="h-4 w-4 mr-2" />
            Explore More Courses
          </Link>
        </Button>
      )}
    </div>
  )
}
