'use client'

import { useEffect, useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import * as THREE from 'three'

interface Particle {
  position: THREE.Vector3
  velocity: THREE.Vector3
}

function ParticleNetwork() {
  const particlesRef = useRef<Particle[]>([])
  const pointsGeometryRef = useRef<THREE.BufferGeometry | null>(null)
  const linesGeometryRef = useRef<THREE.BufferGeometry | null>(null)
  const pointsRef = useRef<THREE.Points | null>(null)
  const linesRef = useRef<THREE.LineSegments | null>(null)

  // Initialize particles and geometries
  useMemo(() => {
    const particles: Particle[] = []
    const particleCount = 50

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        position: new THREE.Vector3(
          (Math.random() - 0.5) * 100,
          (Math.random() - 0.5) * 100,
          (Math.random() - 0.5) * 80,
        ),
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.3,
          (Math.random() - 0.5) * 0.3,
          (Math.random() - 0.5) * 0.2,
        ),
      })
    }

    particlesRef.current = particles

    // Points geometry
    const pointsGeometry = new THREE.BufferGeometry()
    const pointsPositions = new Float32Array(particleCount * 3)
    particles.forEach((p, i) => {
      pointsPositions[i * 3] = p.position.x
      pointsPositions[i * 3 + 1] = p.position.y
      pointsPositions[i * 3 + 2] = p.position.z
    })
    pointsGeometry.setAttribute(
      'position',
      new THREE.BufferAttribute(pointsPositions, 3),
    )
    pointsGeometryRef.current = pointsGeometry

    // Lines geometry
    const linesGeometry = new THREE.BufferGeometry()
    const maxLines = (particleCount * (particleCount - 1)) / 2
    const linePositions = new Float32Array(maxLines * 6)
    linesGeometry.setAttribute(
      'position',
      new THREE.BufferAttribute(linePositions, 3),
    )
    linesGeometry.setDrawRange(0, 0)
    linesGeometryRef.current = linesGeometry

    // Materials
    const pointsMaterial = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.8,
    })

    const linesMaterial = new THREE.LineBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.15,
      fog: false,
    })

    // Create objects
    const points = new THREE.Points(pointsGeometry, pointsMaterial)
    const lines = new THREE.LineSegments(linesGeometry, linesMaterial)

    pointsRef.current = points
    linesRef.current = lines

    return () => {
      pointsGeometry.dispose()
      linesGeometry.dispose()
      pointsMaterial.dispose()
      linesMaterial.dispose()
    }
  }, [])

  useFrame(() => {
    const particles = particlesRef.current
    if (!particles || particles.length === 0) return

    // Update particles
    const bounds = 50
    particles.forEach((particle) => {
      particle.position.add(particle.velocity)

      if (particle.position.x > bounds) particle.position.x = -bounds
      if (particle.position.x < -bounds) particle.position.x = bounds
      if (particle.position.y > bounds) particle.position.y = -bounds
      if (particle.position.y < -bounds) particle.position.y = bounds
      if (particle.position.z > 40) particle.position.z = -40
      if (particle.position.z < -40) particle.position.z = 40

      particle.velocity.x += (Math.random() - 0.5) * 0.02
      particle.velocity.y += (Math.random() - 0.5) * 0.02
      particle.velocity.z += (Math.random() - 0.5) * 0.01
      particle.velocity.multiplyScalar(0.995)
    })

    // Update points
    const pointsGeometry = pointsGeometryRef.current
    if (pointsGeometry) {
      const positions = pointsGeometry.attributes.position as THREE.BufferAttribute
      const array = positions.array as Float32Array
      particles.forEach((p, i) => {
        array[i * 3] = p.position.x
        array[i * 3 + 1] = p.position.y
        array[i * 3 + 2] = p.position.z
      })
      positions.needsUpdate = true
    }

    // Update lines
    const linesGeometry = linesGeometryRef.current
    if (linesGeometry) {
      const positions = linesGeometry.attributes.position as THREE.BufferAttribute
      const array = positions.array as Float32Array
      let idx = 0
      const maxDist = 25

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          if (particles[i].position.distanceTo(particles[j].position) < maxDist) {
            array[idx * 3] = particles[i].position.x
            array[idx * 3 + 1] = particles[i].position.y
            array[idx * 3 + 2] = particles[i].position.z
            idx++
            array[idx * 3] = particles[j].position.x
            array[idx * 3 + 1] = particles[j].position.y
            array[idx * 3 + 2] = particles[j].position.z
            idx++
          }
        }
      }

      positions.needsUpdate = true
      linesGeometry.setDrawRange(0, idx)
    }
  })

  return (
    <>
      {pointsRef.current && <primitive object={pointsRef.current} />}
      {linesRef.current && <primitive object={linesRef.current} />}
    </>
  )
}

export function ParticleNetworkBackground() {
  return (
    <div className="fixed inset-0 w-full h-full bg-black -z-10">
      <Canvas
        camera={{ position: [0, 0, 60], fov: 75 }}
        style={{ width: '100%', height: '100%' }}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: 'high-performance',
          clearColor: 0x000000,
        }}
        dpr={[1, 2]}
      >
        <color attach="background" args={['#000000']} />
        <ParticleNetwork />
      </Canvas>
    </div>
  )
}
